MID=" " # Give your Paytm Merchant ID
MK=" " #Give your Patym Merchant Key